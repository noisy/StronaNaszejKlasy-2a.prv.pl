<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-type"
 content="text/html; charset=iso-8859-2">
  <meta name="Keywords"
 content="II A, II LO, Liceum Og�lnokszta�conce, Wodzis�aw �l�ski, 1987, kaj-jo-je, mat - inf, Krzysiek Szumny, Noisy">
  <meta name="Description" content="">
  <meta name="Author" content="Noisy - Krzysztof Szumny">
  <title>StronaNaszejKlasy-2a.prv.pl</title>
  <link href="styl.css" rel="stylesheet" type="text/css">
</head>
<body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0">
<table align="center" border="0" cellpadding="0" cellspacing="0"
 height="100%" width="770">
  <tbody>
    <tr>
      <td colspan="2" class="kolor3" height="50" width="770">
      <h1><big>W W W . K A J . J E . J O . P L </big><br>
      </h1>
      </td>
    </tr>
    <tr>
      <td class="kolor" height="100%" width="160"><!-- Pocz�tek menu 1 - lewy panel -->
      <p>&nbsp;</p>
      <p class="menu"><a href="okno/klasa.html" class="panel"
 target="okno">Nasza
klasa</a></p>
      <p class="menu"><a href="http://lowodz.home.pl" class="panel"
 target="_blank">Nasza
szko�a</a><br>
      <br>
      </p>
      <p class="menubig">&nbsp;MENU<br>
      </p>
      <p class="menu"><a href="http://www.ksiega-2a.prv.pl/"
 class="panel">Ksi�ga
go�ci</a> </p>
      <p class="menu" style="color: rgb(255, 255, 255);">&nbsp; IRC
chat</p>
      <p class="menu" style="color: rgb(255, 255, 255);">&nbsp; Web
Gadu-Gadu</p>
      <p class="menu"><a href="okno/sonda.html" class="panel"
 target="okno">Sonda</a> </p>
<!-- Koniec menu 1 -->
<!-- Pocz�tek menu 2 - lewy panel -->
      <p class="menubig">&nbsp;NIEZB�DNIK</p>
      <p class="menu"><a href="okno/plan.html" class="panel"
 target="_blank">Plan
lekcji</a></p>
      <p class="menu"><a href="okno/numerki.html" class="panel"
 target="okno">Szcz�liwy
Numerek</a></p>
      <p class="menu"><a href="okno/ezeszyt.html" class="panel"
 target="okno">E-zeszyt</a></p>
      <p class="menu"><a href="okno/spr.html" class="panel"
 target="okno">Spr.
i kartk�wki</a></p>
      <p class="menu"><a href="okno/dzienniczek.html" class="panel"
 target="okno">Tw�j
dzienniczek</a></p>
      <p class="menu"><a href="okno/zada.html" class="panel"
 target="okno">Zadania
domowe</a></p>
      <p class="menu" style="color: rgb(255, 255, 255);">&nbsp; Spis
temat�w</p>
<!-- Koniec menu 2 -->
<!-- Pocz�tek menu 3 - lewy panel -->
      <p class="menubig">&nbsp;ARCHIWUM</p>
      <p class="menu" style="color: rgb(255, 255, 255);"><a
 href="okno/galeria.html" target="okno" class="panel">Galeria
zdj��</a></p>
      <p class="menu" style="color: rgb(255, 255, 255);">&nbsp; Filmy
i filmiki</p>
      <p class="menu"><span style="color: rgb(255, 255, 255);">&nbsp;
Powiedzonka
z lekcji</span><a href="lewe/powiedzonka.html" class="panel"><br>
      </a></p>
      <p class="menubig">&nbsp;SUBSKRYPCJA GG<br>
      </p>
      <p class="menu" style="text-align: center;"><a
 href="okno/subgg.html" class="panel" target="okno">Co to jest i
jak dzia�a subskrupcja?</a></p>
      <form action="subgg/subscript.php" method="post">
        <div style="text-align: center;"><input type="text" name="uid"
 maxlength="11"><br>
        </div>
        <div style="text-align: center;"><input type="checkbox"
 name="mode" value="del" style="color: rgb(255, 255, 255);"> <span
 style="color: rgb(255, 255, 255);"> Usun m�j numer</span><br>
        </div>
        <div style="text-align: center;"><input type="submit"
 name="submit" value="Wykonaj"
 style="background-color: rgb(240, 240, 240);"></div>
      </form>
<!-- Koniec menu 3 --> </td>
      <td height="100%" width="610">
      <table border="0" cellpadding="0" cellspacing="0" height="100%"
 width="610">
        <tbody>
          <tr>
            <td class="kolor2" colspan="2" height="20" width="610"><!-- Pocz�tek menu g�rnego -->
            <table border="0" cellpadding="0" cellspacing="0"
 height="20" width="610">
              <tbody>
                <tr>
                  <td class="ramka" width="122"><a
 href="okno/aktualnosci.html" class="top" target="okno"><img
 src="img/point2.gif" width="12" height="12" border="0" alt=""
 align="left">Stronag��wna<br>
                  </a></td>
                  <td class="ramka" width="122"
 style="color: rgb(255, 255, 255);"><img src="img/point.gif" width="12"
 height="12" border="0" alt="" align="left">Download</td>
                  <td class="ramka" width="122"><a href="okno/link.html"
 target="okno" class="top"><img src="img/point2.gif" width="12"
 height="12" border="0" alt="" align="left">Linkownia<br>
                  </a> </td>
                  <td class="ramka" width="122"
 style="color: rgb(255, 255, 255);"><img src="img/point.gif" alt=""
 align="left" border="0" height="12" width="12">Inne<br>
                  </td>
                  <td class="ramka" width="122"><a
 href="okno/kontakty.html" class="top" target="okno"><img
 src="img/point2.gif" alt="" align="left" border="0" height="12"
 width="12">Kontakty<br>
                  </a></td>
                </tr>
              </tbody>
            </table>
<!-- Koniec menu g�rnego --> </td>
          </tr>
          <tr>
            <td height="100%" width="440"><iframe width="100%"
 height="1611" frameborder="0" src="okno/aktualnosci.html"
 id="autoiframe" scrolling="no" name="okno">Twoja
przegl�darka
nie akceptuje p�ywaj�cych ramek</iframe> <br>
            </td>
<!-- Pocz�tek prawego panela --> <td class="kolor2" height="100%"
 width="170">
            <p class="menubigright">CZAS I DATA</p>
            <center>
            <embed src="img/clockcalendar.swf" quality="high"
 bgcolor="339999" width="160" height="160" align=""
 type="application/x-shockwave-flash"
 pluginspage="http://www.macromedia.com/go/getflashplayer" menu="false"></center>
            <p class="menubigright">SZCZʦLIWY NUMEREK</p>
            <p class="panel"><!-- skrypt w php ktory sam wyswietla numerki na nastepny dzien-->
            <script language="php">
$dzien=date("d");

$dzien++;
 
echo("Na $dzien.04 nie musza sie uczyc nr: <B>");

switch($dzien)
{ 
case 15: echo("18, 15"); break;
case 18: echo("32, 13"); break;
case 19: echo("37, 34"); break;
case 20: echo("19, 16"); break;
case 21: echo("25, 7"); break;
case 22: echo("26, 8"); break;
case 25: echo("33"); break;
case 26: echo("29"); break;
case 27: echo("2"); break;
case 28: echo("10"); break;
case 29: echo("24"); break;


}

echo("</b>");
            </script>
            </p>
            <p class="menubigright">LICZNIK</p>
<!-- LICZNIK OS�B OBECNIE B�D�CYCH NA STRONIE-->
            <p class="panel" style="text-align: center;">Go�ci na
stronie<br>
            <b>
            <script src="http://www.numerator.pl/licznik.php?id=54546"></script></b></p>
            <div style="text-align: center;"><!-- LICZNIK DZIENNYCH ODWIEDZIN-->
            </div>
            <p class="panel" style="text-align: center;">Odwiedzin dzi�<br>
            <b>
            <script src="http://www.numerator.pl/licznik.php?id=54545"></script></b></p>
            <div style="text-align: center;"><!-- LICZNIK DZIENNYCH ODWIEDZIN-->
            </div>
            <p class="panel" style="text-align: center;">Wy�wietle�
strony<br>
            <b>
            <script src="http://www.numerator.pl/licznik.php?id=54544"></script></b></p>
            <p class="menubigright">INNE KLASY</p>
            <p class="menu"><a
 href="http://www.prv.pl/klikometr/index.php?i=1629" target="_blank"
 class="panel">Klasa
I G</a></p>
            <p class="menubigright">BANERY</p>
<!--        ###############################          BANER PAJACYKA      ##############################                    -->
            <div style="text-align: center;"><a
 href="http://www.pajacyk.pl/" target="_blank"><img
 src="http://www.pajacyk.pl/ban_pajac/pajacyk_139x68.gif"
 style="border: 0px solid ; width: 139px; height: 68px;"
 alt="Nakarm g�odne dziecko - wejd� na stron� www.Pajacyk.pl" title=""
 vspace="5"></a></div>
<!--######################################       BANER POLSKIEGO SERCA        ########################################-->
            <div align="center"><object
 classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
 width="120" height="50" id="polskieserce120x50" align=""> <param
 name="movie"
 value="http://www.polskieserce.pl/nasze_bannery/polskieserce120x50.swf">
            <param name="quality" value="high"> <param name="bgcolor"
 value="#FFFFFF">
            <embed
 src="http://www.polskieserce.pl/nasze_bannery/polskieserce120x50.swf"
 quality="high" bgcolor="#FFFFFF" width="139" height="68"
 name="polskieserce120x50" align="" type="application/x-shockwave-flash"
 pluginspage="http://www.macromedia.com/go/getflashplayer"></object> </div>
<!-- Koniec prawego panela --> </td>
          </tr>
        </tbody>
      </table>
      </td>
    </tr>
    <tr>
      <td colspan="2" class="kolor" height="20" width="770">
      <center><a href="okno/kontakty.html" target="okno">redakcja: </a><a
 href="okno/kontakty.html" target="okno">Noisy</a><a
 href="okno/kontakty.html" target="okno"> &amp; Pio</a><br>
      </center>
      </td>
    </tr>
  </tbody>
</table>
</body>
</html>
