<?php


// phpBB 2.x auto-generated config file
// Do not change anything in this file!

$dbms = 'mysql4';

$dbhost = 'sql.noisy.nazwa.pl';
$dbname = 'noisy';
$dbuser = 'noisy';
$dbpasswd = '123123';

$table_prefix = 'phpbb_';

define('PHPBB_INSTALLED', true);

?>